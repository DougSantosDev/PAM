import { View, Text, StyleSheet, Image } from 'react-native';

export default function TelaInformacoes() {
  return (
    <View style={styles.container}>
      <Image 
        source={{ uri: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80' }}
        style={styles.imagem}
        resizeMode="cover"
      />
      <View style={styles.conteudo}>
        <Text style={styles.titulo}>Sobre o Aplicativo</Text>
        <Text style={styles.texto}>
          Este aplicativo foi desenvolvido com React Native para fornecer um catálogo
          de produtos completo e intuitivo.
        </Text>
        <Text style={styles.texto}>
          Versão: 1.0.0
        </Text>
        <Text style={styles.texto}>
          Desenvolvido por: Douglas Santos
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  imagem: {
    width: '100%',
    height: 200,
  },
  conteudo: {
    padding: 20,
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
    textAlign: 'center',
  },
  texto: {
    fontSize: 16,
    lineHeight: 24,
    color: '#555',
    marginBottom: 15,
    textAlign: 'center',
  },
});