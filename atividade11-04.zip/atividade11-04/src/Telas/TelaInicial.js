import { View, Text, StyleSheet, TouchableOpacity, ImageBackground } from 'react-native';

export default function TelaInicial({ navigation }) {
  return (
    <ImageBackground 
      source={{ uri: 'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80' }}
      style={styles.container}
      blurRadius={2}
    >
      <View style={styles.overlay}>
        <Text style={styles.titulo}>Bem-vindo ao Catálogo de Produtos!</Text>
        <Text style={styles.subtitulo}>Encontre os melhores produtos com os melhores preços</Text>
        
        <View style={styles.botoes}>
          <TouchableOpacity
            style={styles.botao}
            onPress={() => navigation.navigate('Produtos')}
          >
            <Text style={styles.textoBotao}>Ver Produtos</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.botao, styles.botaoSecundario]}
            onPress={() => navigation.navigate('Informacoes')}
          >
            <Text style={[styles.textoBotao, styles.textoBotaoSecundario]}>Informações</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  overlay: {
    backgroundColor: 'rgba(0,0,0,0.5)',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 10,
    color: 'white',
    textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  subtitulo: {
    fontSize: 16,
    marginBottom: 40,
    color: 'white',
    textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  botoes: {
    width: '80%',
  },
  botao: {
    backgroundColor: '#2ecc71',
    padding: 15,
    borderRadius: 30,
    marginBottom: 15,
    alignItems: 'center',
    elevation: 3,
  },
  botaoSecundario: {
    backgroundColor: 'white',
  },
  textoBotao: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  textoBotaoSecundario: {
    color: '#2ecc71',
  },
});