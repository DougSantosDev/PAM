import { View, Text, StyleSheet, FlatList, TouchableOpacity, Image } from 'react-native';

const produtos = [
  { 
    id: '1', 
    nome: 'Smartphone', 
    preco: 'R$ 1.999,00',
    imagem: 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    descricao: 'Smartphone de última geração com câmera de 108MP e bateria de longa duração.'
  },
  { 
    id: '2', 
    nome: 'Notebook', 
    preco: 'R$ 4.599,00',
    imagem: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    descricao: 'Notebook potente com processador i7 e placa de vídeo dedicada.'
  },
  { 
    id: '3', 
    nome: 'Tablet', 
    preco: 'R$ 1.299,00',
    imagem: 'https://images.unsplash.com/photo-1546054454-aa26e2b734c7?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    descricao: 'Tablet ideal para produtividade e entretenimento com tela de alta resolução.'
  },
  // Adicione mais produtos conforme necessário
];

export default function TelaProdutos({ navigation }) {
  return (
    <View style={styles.container}>
      <FlatList
        data={produtos}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => navigation.navigate('Detalhes', { produto: item })}
          >
            <Image 
              source={{ uri: item.imagem }} 
              style={styles.imagem} 
              resizeMode="cover"
            />
            <View style={styles.infoContainer}>
              <Text style={styles.nome}>{item.nome}</Text>
              <Text style={styles.preco}>{item.preco}</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: '#f5f5f5',
  },
  item: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 10,
    marginBottom: 10,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  imagem: {
    width: 100,
    height: 100,
  },
  infoContainer: {
    flex: 1,
    padding: 15,
    justifyContent: 'center',
  },
  nome: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  preco: {
    fontSize: 16,
    color: '#2ecc71',
    fontWeight: '600',
  },
});