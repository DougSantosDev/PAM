import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';

export default function TelaDetalhes({ route }) {
  const { produto } = route.params;

  return (
    <ScrollView style={styles.container}>
      <Image 
        source={{ uri: produto.imagem }} 
        style={styles.imagem} 
        resizeMode="cover"
      />
      <View style={styles.detalhesContainer}>
        <Text style={styles.titulo}>{produto.nome}</Text>
        <Text style={styles.preco}>{produto.preco}</Text>
        <Text style={styles.descricao}>{produto.descricao}</Text>
        
        {/* Adicionando características do produto */}
        <View style={styles.caracteristicas}>
          <Text style={styles.subtitulo}>Características:</Text>
          <View style={styles.lista}>
            <Text style={styles.itemLista}>• Alta performance</Text>
            <Text style={styles.itemLista}>• Design moderno</Text>
            <Text style={styles.itemLista}>• Garantia de 1 ano</Text>
            <Text style={styles.itemLista}>• Frete grátis para todo Brasil</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  imagem: {
    width: '100%',
    height: 300,
  },
  detalhesContainer: {
    padding: 20,
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  preco: {
    fontSize: 24,
    color: '#2ecc71',
    fontWeight: '600',
    marginBottom: 20,
  },
  descricao: {
    fontSize: 16,
    lineHeight: 24,
    color: '#555',
    marginBottom: 30,
  },
  caracteristicas: {
    marginTop: 20,
  },
  subtitulo: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 10,
    color: '#333',
  },
  lista: {
    marginLeft: 10,
  },
  itemLista: {
    fontSize: 16,
    lineHeight: 24,
    color: '#555',
  },
});